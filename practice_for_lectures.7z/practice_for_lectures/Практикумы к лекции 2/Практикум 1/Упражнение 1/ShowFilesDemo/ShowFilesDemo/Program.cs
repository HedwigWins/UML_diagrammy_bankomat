﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ShowFilesDemo
{
    class Program
    {
        static void Main(string[] args)
            Directorylnfo dir = new Directorylnfo(Environment.SystemDirectory);
            ShowDirectory(dir);
        {
            static void ShowDirectory(Directorylnfo dir)
            {
                // Показать все файлы
                foreach (Filelnfo file in dir.GetFilesO)
                {
                    Console.WriteLine("File: {0}", file.FullName);
                }
                foreach (Directorylnfo subDir in dir.GetDirectoriesO)
                {
                    ShowDirectory(subDir);
                }
            }

        }
    }
}

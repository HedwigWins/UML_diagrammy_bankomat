using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ViewFile
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            try
            {
                TextReader tr = new StreamReader(locationTextBox.Text);
                try
                { displayTextBox.Text = tr.ReadToEnd(); }
                catch (Exception ex)
                { MessageBox.Show(ex.Message); }
                finally
                { tr.Close(); }
            }
            catch (System.IO.FileNotFoundException ex)
            { MessageBox.Show("Sorry, the file does not exist."); }
            catch (System.UnauthorizedAccessException ex)
            { MessageBox.Show("Sorry, you lack sufficient privileges."); }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }
    }
}